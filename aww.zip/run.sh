mv /data/data/com.xontwol.xt/files/libx4930320304380061273234204.so /data/local/tmp/libx4930320304380061273234204.so
chmod 755 /data/local/tmp/libx4930320304380061273234204.so
/data/data/com.xontwol.xt/files/x870325077578615300 -pkg com.tencent.ig -lib /data/local/tmp/libx4930320304380061273234204.so -hide_maps -hide_solist -dl_memfd